<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<footer>
        <img id="footer-img" src="../Img\logo.png" alt=""> 

        
        <ul class="general-info">
            <li>+7(812)660-50-54</li>
            <li>+7(958)111-95-03</li>
            <li>Пн-вс: с 10:00 до 21:00</li>
            <li>Проспект Стачек 67 к.5</li>
            <li>Лиговский проспект 205</li>
            <li>Гражданский проспект, 116 к.5</li> 
        </ul>

      <div class="info-user">
            <h4>Для клиента</h4>

            <ul class="info-user">
                <li>Как купить</li>
                <li>Доставка и оплата</li>
                <li>кредит</li>
                <li>политика конфиденциальности</li>
                <li>Вопросы и ответы (F.A.Q.)</li>
                <li>Сервис и гарантия</li>
            </ul>
        </div>

        <div>
             <h4>О магазине</h4>

             <ul class="info-shop">
                <li>Отзывы</li>
                <li>Наши преимущества</li>
                <li>История компании</li>
                <li>Сотрудничество</li>
                <li>Партнермкая программа</li>
                <li>Вакансии</li>
             </ul>
        </div>
       
        <div>
            <h4>Сотрудничество</h4>

            <ul class="cooperation">
                <li>Оптом</li>
                <li>Дропшиппинг</li>
            </ul>
        </div>
    </footer>
</body>
</html>